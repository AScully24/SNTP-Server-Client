/* 
 * File:   client.h
 * Author: Anthony Scully
 *
 * Created on 30 March 2015, 20:31
 */

#ifndef CLIENT_H
#define	CLIENT_H

void clientHandler(int , struct sockaddr);

#endif	/* CLIENT_H */

